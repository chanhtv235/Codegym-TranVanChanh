package Case_Study.JavaCore.SaveToFile.Commons;

import java.util.Scanner;

public class ScannerUtils {
    public static Scanner scanner = new Scanner(System.in);
}
