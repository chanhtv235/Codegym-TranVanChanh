package Case_Study.JavaCore.SaveToFile.CustomException;

public class NameException extends Exception {
    public NameException(String message) {
        super(message);
    }
}
