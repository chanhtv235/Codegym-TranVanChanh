package Case_Study.JavaCore.SaveToFile.Views;

import Case_Study.JavaCore.SaveToFile.Controllers.MainController;

public class Main {
    public static void main(String[] args) {
        MainController.processMain();
    }
}
